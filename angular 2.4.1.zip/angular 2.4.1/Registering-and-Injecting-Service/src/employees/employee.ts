export interface IEmployee{
	id:Number,
	name:String
}