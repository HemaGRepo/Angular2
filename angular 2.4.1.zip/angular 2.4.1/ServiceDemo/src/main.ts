import { Component,Inject,OnInit,NgModule,enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { PersonService } from './person.service'
import { IPerson } from './person'

enableProdMode();

@Component({
  selector: 'my-app',
  templateUrl:'src/service.component.html'
})


export class PersonComponent implements OnInit{
   persons:IPerson[];
  constructor(@Inject(PersonService) private personService:PersonService){
    
  }
  
  ngOnInit(): void{
    this.persons = this.personService.getPersons();
  }
  
}

@NgModule({
  imports:[ BrowserModule ],
  declarations:[ PersonComponent ],
  providers:[PersonService],
  bootstrap:[ PersonComponent ]
})
class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);