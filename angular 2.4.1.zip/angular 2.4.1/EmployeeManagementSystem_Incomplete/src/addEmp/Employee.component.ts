import { Component, NgModule, enableProdMode,Injectable,Inject } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms'
import { Employee } from './Employee'
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { ActivatedRoute,Router, Params } from '@angular/router';
enableProdMode();

@Component({
  selector: 'my-app',
  templateUrl: 'addEmp/employee.component.html'
})
@Injectable()
export class EmpComponent {
 constructor(@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){
         
    }
onSubmit(emp:Employee,isValid:boolean){
   this.router.navigate(['/home']);
}


  