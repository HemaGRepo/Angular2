import { Component,Inject,OnInit,NgModule,enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { EmployeeService } from './employee.service'
import { Employee } from './employee'

enableProdMode();

@Component({
  selector: 'my-app',
  templateUrl:'viewEmp/employee.component.get.html'
})
export class ViewEmployeeComponent implements OnInit{
   employees:Employee[];
  constructor(@Inject(EmployeeService) private empService:EmployeeService){
    
  }
  
  ngOnInit(): void{
    this.employees = this.empService.getEmployee();
  }
  
}
