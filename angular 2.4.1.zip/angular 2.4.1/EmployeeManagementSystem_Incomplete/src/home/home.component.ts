import { Component } from '@angular/core';

@Component({
    template:`
	<div class="container">
		<!-- TESTIMONIALS -->
		<section>
			<div class="page-header" id="section-testimonials">
				<h2>Testimonials. <small>This is what our customers are saying about us.</small></h2>
			</div> <!-- end page-header -->

			<div class="row">
				<div class="col-md-4">
					<blockquote>
						<p>This site relieved us of the major activies involved in Employee Management. Thanks to the team. Looking forward for more such Products from your team</p>
						<footer>Cite author</footer>
					</blockquote>
				</div>
				<div class="col-md-4">
					<blockquote>
						<p>New Employee Data Management is no more a hercules task. The portal is user friendly and tailor made to our requirements</p>
						<footer>Cite author</footer>
					</blockquote>
				</div>
				<div class="col-md-4">
					<blockquote>
						<p>This Employee portal is an user friendy interface for all employee details</p>
						<footer>Cite author</footer>
					</blockquote>
				</div>
			</div> <!-- end row -->
	`
})


export class HomeComponent {

}

