import { Component,Inject,OnInit,NgModule,enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { EmployeeService } from './employee.service'
import { Employee } from './employee';
import { ActivatedRoute,Router, Params } from '@angular/router';

enableProdMode();

@Component({
  selector: 'my-app',
  templateUrl:'src/viewEmp/employee.component.get.html'
})
export class ViewEmployeeComponent implements OnInit{
   employees:Employee[];
   constructor(@Inject(EmployeeService) private empService:EmployeeService,@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){
         
    }
  
  ngOnInit(): void{
    this.employees = this.empService.getEmployee();
  }
  navigateToHome():void{
        this.router.navigate(['/home']);
    }
}
