import { Component,Injectable,Inject,OnInit,NgModule,enableProdMode } from '@angular/core';
import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import 'rxjs/Rx'; 
import { Employee } from './employee';
import { DisplayService } from './display.service';
import { ActivatedRoute,Router, Params } from '@angular/router';
enableProdMode();

@Component({
  selector: 'my-app',
  templateUrl: 'src/display/display.component.html',
  providers: [ DisplayService ]
})


export class DisplayComponent implements OnInit{
    private emps:Employee[];
    private id:number;//
    private errorMessage:any;
    
    constructor(@Inject(DisplayService) private service:DisplayService,@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){
         this.id = parseInt(this.route.snapshot.params['id']);//
    }
    
    ngOnInit():void{
         this.service.getAllEmps().subscribe(employees=>this.emps = employees,error=>this.errorMessage=error);
    }
	navigateToHome():void{
        this.router.navigate(['/home']);
    }
	navigateToView():void{
        this.router.navigate(['/viewEmp']);
    }
	navigateToSearch():void{
        this.router.navigate(['/search']);
    }
}


  