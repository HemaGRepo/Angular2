import { Component,Injectable,Inject } from '@angular/core';
import { ActivatedRoute,Router, Params } from '@angular/router';

@Component({
    template:`
	<div class="container">
	<table><tr>
	<td class="col-mg-4">
	<h1>You are Offline! Data will be added once the server is up... </h1>
	</td>
    <td class="col-mg-4">
	</td>
	</tr>
	</table>
	</div>
	<hr/>
	
    <button type="button" class="btn btn-primary" (click)='navigateToHome()'>Go to Home</button>`
})


@Injectable()
export class AddComponent {
    constructor(@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){
       
    }
  
}
