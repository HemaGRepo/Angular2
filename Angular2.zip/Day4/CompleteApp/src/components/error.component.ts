import { Component,Injectable,Inject } from '@angular/core';
import { ActivatedRoute,Router, Params } from '@angular/router';

@Component({
    template:`
	<div class="container">
	<h1> Sorry ! Invalid Credentials</h1>
	<hr/>
	
    <button type="button" class="btn btn-primary" (click)='navigateToHome()'>Go to Home</button>`
})


@Injectable()
export class ErrorComponent {
    constructor(@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){
       
    }
  navigateToHome()
  {
  this.router.navigate(['/home']);
  }
}
