import { Component,Injectable,Inject } from '@angular/core';
import { ActivatedRoute,Router, Params } from '@angular/router';
import { DisplayService } from '../service/display.service'
import { Employee } from '../model/employee';
import 'rxjs/Rx'; 
@Component({
    templateUrl:'src/views/display.component.html'
})


@Injectable()
export class ViewComponent {
    employees:Employee[];
   constructor(@Inject(DisplayService) private empService:DisplayService,@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){
         
    }
  
  ngOnInit(): void{
     this.empService.getAllEmps().subscribe(employees=>this.employees = employees,error=>this.errorMessage=error);
  }
  navigateToHome():void{
        this.router.navigate(['/home']);
    }
  
}
