import { Component,Inject } from '@angular/core';
import { ActivatedRoute,Router, Params } from '@angular/router';
@Component({
    templateUrl:'src/views/home.component.html';
})


export class HomeComponent {
errorMsg:string;
constructor(@Inject(ActivatedRoute) private route:ActivatedRoute,@Inject(Router) private router:Router){
    }

onSubmit(name:string,pwd:string)
{
   if(name=="Capgemini" && pwd =="chennai")
    {
		this.router.navigate(['/view']);
	 }
	else
	{
		this.router.navigate(['/error']);
	 }
}
}

