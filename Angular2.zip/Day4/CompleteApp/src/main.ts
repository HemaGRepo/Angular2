import { Component, NgModule, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Routes, RouterModule }   from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HomeComponent } from './components/home.component';
import { AddComponent } from './components/add.component';
import { ViewComponent } from './components/view.component';
import { ErrorComponent } from './components/error.component';
import {AboutComponent } from './components/about.component';
import { DisplayService } from './service/display.service'

enableProdMode();

@Component({
  selector: 'my-app',
   templateUrl:'src/views/main.html'
})
export class AppComponent { 
}

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home',  component: HomeComponent },
  { path: 'add',  component: AddComponent },
  { path: 'view',  component: ViewComponent },
	{ path: 'error',  component: ErrorComponent },
		{ path: 'about/:empid',  component: AboutComponent }
];

@NgModule({
    imports:[ BrowserModule, RouterModule.forRoot(routes ,{ useHash: true }),FormsModule,HttpModule],
    declarations:[ AppComponent, HomeComponent,AboutComponent, ViewComponent,AddComponent,ErrorComponent],
    providers:[DisplayService],
	bootstrap:[ AppComponent ]
})
export class AppModule {
}
platformBrowserDynamic().bootstrapModule(AppModule);