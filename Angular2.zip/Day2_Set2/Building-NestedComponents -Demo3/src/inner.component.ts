import { Component,Output,EventEmitter } from '@angular/core';
import { ParentComponent } from './outer.component';

@Component({
  selector: 'child-selector',
  template: ` <h2>Hi, I'm a nested component</h2>  
		  <span (click)='onClick()'>Click me please!</span> `
})

export class ChildComponent {  
  @Output() notify: EventEmitter<string> = new EventEmitter<string>();

  onClick() {
    this.notify.emit("Click from nested component");
  }
}
