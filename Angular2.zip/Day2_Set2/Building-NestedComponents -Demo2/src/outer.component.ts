import { Component } from '@angular/core';
import { ChildComponent } from './inner.component';

@Component({
  selector: 'my-app',
  template: `<div>  
			  <h1>I'm a container component</h1>
			  <child-selector [abcd]='childTitle'></child-selector>
			 </div> `

})
export class ParentComponent {
childTitle:string = 'This text is passed to child';
 }  