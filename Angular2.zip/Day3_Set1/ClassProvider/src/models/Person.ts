export class Person{
	name:string;
	age:Number;
	
	constructor(){
		this.name = "John";
		this.age = 24;
	}
}