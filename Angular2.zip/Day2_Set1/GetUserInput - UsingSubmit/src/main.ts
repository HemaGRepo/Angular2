import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode } from '@angular/core';
import { NgModule } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

enableProdMode();

@Component({
  selector: 'my-app',
  template: `<div>
	<h1>$event object</h1>
	<input type="text" (keyup)='onKey($event)'/>
	<hr/>
	<input type="submit" (click)='showValue()' value="Submit"/>
	<h1 *ngIf="show" [innerText]='values'></h1>
	<hr/>
	<h1 *ngIf="show">{{values}}</h1>
	<br/>
	<h1>A new Component invoked</h1>
	<two-way></two-way>
  <div>`
})
export class EventObjectComponent {
	values:string="";
	show:boolean=false;
	onKey(event:any) {
	    this.show=false;
		this.values = event.target.value;
	};
	showValue() {
	    this.show=true;
	};
}

@Component({
  selector: 'two-way',
  template: `<div>
	<h1>Two way object</h1>
	<hr/>
	<h1> Value fetched using Two way Binding </h1>
	<h1>{{n1}}</h1>
  <div>`
})
export class TwoWayDemoComponent {
	n1:string="Value not assigned";
}

@NgModule({
	imports:[ BrowserModule ],
	declarations:[ EventObjectComponent,TwoWayDemoComponent ],
	bootstrap:[ EventObjectComponent ]
})
export class AppComponent{}

platformBrowserDynamic().bootstrapModule(AppComponent);