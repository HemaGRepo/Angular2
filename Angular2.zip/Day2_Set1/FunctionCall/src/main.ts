import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { enableProdMode,Component,NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

enableProdMode();

@Component({
  selector: 'my-app',
  template: `
    <div>
      <h2>{{greet}}</h2>
	  <h1>Calling .... {{display()}}</h1>
    </div>`
})
export class AppComponent {
	greet:string="Hello Angular2!";
	display():string
	{
	  return "Welcome to Functions ";
	}
}

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
platformBrowserDynamic().bootstrapModule(AppModule);