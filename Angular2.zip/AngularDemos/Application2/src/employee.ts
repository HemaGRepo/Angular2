export class Employee{
id:number;
name:string;
sal:number;
}
