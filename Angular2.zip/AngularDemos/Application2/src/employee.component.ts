//our root app component
import { Component } from '@angular/core'
import { Employee } from './employee'

@Component(
{
 selector:'my-app',
 templateUrl:'src/emp.comp.html'
}
)
export class EmployeeComponent {
	emp:Employee=new Employee();
	constructor()
	{
	 this.emp.id=10;
	 this.emp.name="Allen";
	 this.emp.sal=89898;
	}
}