import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { EmployeeComponent }  from './employee.component';

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ EmployeeComponent ],
  bootstrap:    [ EmployeeComponent ]
})
export class EmployeeModule { }
