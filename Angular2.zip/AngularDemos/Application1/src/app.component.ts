//our root app component
import { Component } from '@angular/core'

@Component(
{
 selector:'my-app',
 template:`<div>
			<h1> Welcome to Angular 2</h1>
			<hr/>
			<h1> Data from Class: {{greet}} </h1>
			<h1> Thank U {{3+5}}</h1>
			</div>`
}
)
export class AppComponent {
	greet:string="Hello Angular2!";
}